<h1>IONIS Document Management System</h1>
<p>
Document Management System is an online system in which students of EPITA and the partnered institutions can share their data and discussion in the forum. This provides the ability to access or download content securely and easily using university single login credentials from any device. Any registered student could upload or find relative document. It includes Multiple File Support. Members can search files with just help of a keyword.</p>

<p>The Technologies used in this Application are PHP for Backend, Bootstrap for Frontend, Mysql for Databases</p>
