<head>
    <title>Website Title</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/screen.css">
    <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.2.min.js"></script>

</head>