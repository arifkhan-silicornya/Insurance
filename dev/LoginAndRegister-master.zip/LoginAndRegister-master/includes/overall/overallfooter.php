    </div>
    <?php include'includes/footer.php';?>
<script type="text/javascript" src="js/script.js"></script>
</body>
</html>