<?php
session_start();
require 'core/database/connect.php';
require 'core/functions/general.php';
require 'core/functions/user.php';
?>