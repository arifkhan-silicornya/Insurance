<?php 
include'includes/overall/overallheader.php'; 
?>
      <h1>Register</h1>
      <p>Registeration</p>
<?php include'includes/overall/overallfooter.php'; ?>