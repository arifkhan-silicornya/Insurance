<?php 
include'includes/overall/overallheader.php'; 
include 'core/init.php';
?>
	<h1>Home</h1>
    <p>Just a template.</p>
<?php include'includes/overall/overallfooter.php';?>