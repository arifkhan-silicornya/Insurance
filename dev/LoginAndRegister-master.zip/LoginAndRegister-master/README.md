# web1.0
Login Register API in PHP<br>
Please note that all functions are compatible to php 5.5 and earlier<br>
But with little changes it can with php 7.0 too. 
