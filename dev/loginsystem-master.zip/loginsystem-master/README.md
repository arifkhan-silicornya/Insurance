# loginsystem
Login sytem written in php and using mySQL as database. Object oriented. With this you can do the following: Register a user, log in, edit your profile information, change password, update a profile text, and log out. Used this video tutorial series from Codesource to do the most parts: http://bit.ly/2g2d1LG
